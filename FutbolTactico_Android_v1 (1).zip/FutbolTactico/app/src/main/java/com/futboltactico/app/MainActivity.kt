package com.futboltactico.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : android.app.Activity() {
    private val green = Color.rgb(11, 92, 44)
    private val light = Color.rgb(242, 247, 243)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(light)
        return root
    }

    private fun title(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 26f
        t.setTextColor(Color.WHITE)
        t.setTypeface(null, 1)
        t.setPadding(20, 24, 20, 24)
        t.setBackgroundColor(green)
        return t
    }

    private fun button(text: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 16f
        b.setOnClickListener { action() }
        return b
    }

    private fun showHome() {
        val root = base()
        root.addView(title("⚽ Fútbol Táctico"))
        val scroll = ScrollView(this)
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(16, 16, 16, 16)

        val intro = TextView(this)
        intro.text = "Aprende a jugar mejor: tácticas, regates, disparos, defensa y lectura de juego."
        intro.textSize = 18f
        intro.setPadding(8, 8, 8, 20)
        content.addView(intro)

        listOf(
            "🧠 Tácticas" to "Formaciones, movimientos y presión.",
            "🕺 Regates" to "Técnicas y ejercicios para superar rivales.",
            "🎯 Disparos" to "Potencia, colocación y definición.",
            "🛡️ Defensa" to "Marcaje, anticipación y posicionamiento.",
            "👀 Lectura de juego" to "Aprende a encontrar espacios y tomar mejores decisiones.",
            "👤 Mi perfil" to "Próximamente: progreso, favoritos y publicaciones."
        ).forEach { (name, desc) ->
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(12, 10, 12, 10)
            val n = TextView(this); n.text = name; n.textSize = 20f; n.setTypeface(null,1)
            val d = TextView(this); d.text = desc; d.textSize = 15f
            box.addView(n); box.addView(d)
            box.setOnClickListener { showSection(name, desc) }
            content.addView(box)
            content.addView(Space(this).apply { minimumHeight = 8 })
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this)
        nav.gravity = Gravity.CENTER
        nav.addView(button("Inicio") { showHome() }, LinearLayout.LayoutParams(0, 60, 1f))
        nav.addView(button("Contenido") { showSection("⚽ Contenido", "Explora las categorías de Fútbol Táctico.") }, LinearLayout.LayoutParams(0, 60, 1f))
        nav.addView(button("Perfil") { showSection("👤 Mi perfil", "Aquí añadiremos tu progreso, favoritos y publicaciones.") }, LinearLayout.LayoutParams(0, 60, 1f))
        root.addView(nav)
        setContentView(root)
    }

    private fun showSection(name: String, desc: String) {
        val root = base()
        root.addView(title(name))
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(20, 24, 20, 20)

        val d = TextView(this)
        d.text = desc
        d.textSize = 18f
        content.addView(d)

        val cards = when {
            name.contains("Tácticas") -> listOf("4-3-3: amplitud y presión", "4-4-2: equilibrio", "Cómo crear líneas de pase")
            name.contains("Regates") -> listOf("Cambio de dirección", "Amague de cuerpo", "Control orientado")
            name.contains("Disparos") -> listOf("Disparo colocado", "Disparo potente", "Definición ante el portero")
            name.contains("Defensa") -> listOf("Marcaje individual", "Cobertura", "Cómo anticipar")
            name.contains("Lectura") -> listOf("Escanear antes de recibir", "Detectar espacios", "Tomar decisiones rápidas")
            else -> listOf("Contenido de ejemplo", "Próximamente habrá videos y ejercicios.")
        }
        cards.forEach {
            val b = button("▶  $it") { Toast.makeText(this, "Contenido: $it", Toast.LENGTH_SHORT).show() }
            content.addView(b)
        }
        content.addView(Space(this).apply { minimumHeight = 20 })
        content.addView(button("← Volver al inicio") { showHome() })
        root.addView(content)
        setContentView(root)
    }
}
